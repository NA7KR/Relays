<?
require_once("connection.php");  	//include your connection to your db
require_once("sqli.php");			//our file which holds our sql functions

	//SELECT
	$query = query("SELECT * FROM blog  LIMIT 10");
	
	//NUM ROWS
	$numRowsCheck = get_num_rows($query); 
	if($numRowsCheck == 0){ header('Location: /'); }
	
	//LOOP THROUGH RESULT
	while($row = fetch_array($query, MYSQL_ASSOC)){
	
		echo $row['title'] ."<br>";
	}
	

?>