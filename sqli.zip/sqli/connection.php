<?php
require("constants.php");

//*SQLi
//Create a database connection
$connection = mysqli_connect(DB_SERVER,DB_USER,DB_PASS,DB_NAME);
if (mysqli_connect_errno($connection)) {
	//echo mysqli_connect_error();
	die("Database connection failed: " . mysqli_connect_error());
}
//*/

 
 
/* SQL
// 1. Create a database connection
$connection = mysql_connect(DB_SERVER,DB_USER,DB_PASS);
if (!$connection) {
	die("Database connection failed: " . mysql_error());
}

// 2. Select a database to use 
$db_select = mysql_select_db(DB_NAME,$connection);
if (!$db_select) {
	die("Database selection failed: " . mysql_error());
}
//*/

?>
