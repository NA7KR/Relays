#!/usr/bin/perl
# 
# Announcement logging  module
#
# Copyright (c) 2012 - Marius Petrescu YO2LOJ
#
#
#

package AnnLog;

use DXVars;
use DXUtil;
use DXLog;
use Julian;
use IO::File;
use DXDebug;
use Data::Dumper;

use strict;

use vars qw($fp $dirprefix);

$fp = 0;						# the DXLog fcb

$dirprefix = "$main::data/ann";

sub init
{
	$fp = DXLog::new('ann', 'dat', 'm');
	confess $@ if $@;
}

# write the current data away
sub logit
{
	my (@field) = @_;
	my $t = time;
	# log it
	if ($field[3] eq "*") # log only announcements
	{
	    my $dest = ($field[5] eq "*")?"ALL":$field[5];
	    $fp->writenow("$t^$field[1]^$dest^$field[6]");
	}
}
1;
__END__;

