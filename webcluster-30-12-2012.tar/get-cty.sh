rm cty.dat
wget http://www.country-files.com/cty/cty.dat
echo `date` > cty.version
rm /spider/data/cty.dat
cp cty.dat /spider/data/cty.dat
/spider/perl/create_prefix.pl
